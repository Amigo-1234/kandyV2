/* ==========================================================================
   Kandy's Treats — Sign in & sign up
   Real Firebase Authentication, following V1's flow. The form markup and
   styling are unchanged; only the behaviour behind them is live now.
   ========================================================================== */
(function (KT) {
  "use strict";

  KT.pages = KT.pages || {};

  function artwork() {
    var img = KT.qs("[data-auth-art]");
    if (img) img.src = KT.images.src("kitchen-story");
  }

  function passwordToggles(root) {
    KT.qsa("[data-pw-toggle]", root).forEach(function (btn) {
      btn.innerHTML = KT.icon("eye", 18);
      btn.addEventListener("click", function () {
        var input = KT.qs("#" + btn.getAttribute("data-pw-toggle"));
        var show = input.type === "password";
        input.type = show ? "text" : "password";
        btn.setAttribute("aria-label", show ? "Hide password" : "Show password");
        btn.style.color = show ? "var(--kt-pink)" : "";
      });
    });
  }

  /** Disable the form until the Firebase module has finished loading. */
  function gate(formSel) {
    var form = KT.qs(formSel);
    if (!form) return;
    var btn = KT.qs("[type=submit]", form);
    var label = btn.textContent;

    function enable(ok) {
      btn.disabled = !ok;
      btn.textContent = ok ? label : "Connecting…";
      if (!ok) return;
      KT.qsa("[data-social]").forEach(function (b) { b.disabled = false; });
    }

    if (KT.services) enable(true);
    else {
      enable(false);
      document.addEventListener("kt:services", function (e) {
        if (e.detail.ok) enable(true);
        else {
          btn.disabled = true;
          btn.textContent = "Unavailable offline";
          KT.toast("We could not reach Kandy's. Check your connection and reload.", "error", { duration: 6000 });
        }
      });
    }
  }

  function busy(form, on, busyLabel) {
    var btn = KT.qs("[type=submit]", form);
    if (!btn.dataset.label) btn.dataset.label = btn.textContent;
    btn.disabled = on;
    btn.textContent = on ? busyLabel : btn.dataset.label;
  }

  function fail(error) {
    KT.toast(KT.services ? KT.services.errorMessage(error) : String(error.message || error),
      "error", { duration: 5200 });
  }

  function socials() {
    KT.qsa("[data-social]").forEach(function (b) {
      var isGoogle = /google/i.test(b.textContent);
      if (!isGoogle) {
        /* V1 only ships Google — do not offer a provider that is not wired. */
        b.remove();
        return;
      }
      b.addEventListener("click", async function () {
        if (!KT.services) return;
        b.disabled = true;
        try {
          var user = await KT.auth.signInWithGoogle();
          if (user) window.location.href = KT.auth.nextUrl();
        } catch (error) {
          fail(error);
        } finally {
          b.disabled = false;
        }
      });
    });
  }

  /* Already signed in? Skip the form. */
  function redirectIfSignedIn() {
    document.addEventListener("kt:auth", function (e) {
      if (e.detail.signedIn) window.location.href = KT.auth.nextUrl();
    });
  }

  /* ---- Sign in --------------------------------------------------------- */

  KT.pages.login = function () {
    artwork();
    passwordToggles(document);
    socials();
    gate("[data-login-form]");
    redirectIfSignedIn();

    var form = KT.qs("[data-login-form]");
    form.addEventListener("submit", async function (e) {
      e.preventDefault();
      if (!KT.services) return;

      var email = KT.qs("#liEmail").value.trim();
      var password = KT.qs("#liPassword").value;
      if (!email || !password) {
        KT.toast("Enter your email and password.", "info");
        return;
      }

      busy(form, true, "Signing you in…");
      try {
        await KT.auth.signIn(email, password);
        window.location.href = KT.auth.nextUrl();
      } catch (error) {
        busy(form, false);
        fail(error);
      }
    });

    var forgot = KT.qs('.authmeta a[href="#"]');
    if (forgot) {
      forgot.addEventListener("click", async function (e) {
        e.preventDefault();
        var email = KT.qs("#liEmail").value.trim();
        if (!email) {
          KT.toast("Enter your email address first, then tap again.", "info");
          return;
        }
        try {
          await KT.auth.resetPassword(email);
          KT.toast("Password reset link sent to " + email, "success", { duration: 5000 });
        } catch (error) {
          fail(error);
        }
      });
    }
  };

  /* ---- Sign up --------------------------------------------------------- */

  KT.pages.signup = function () {
    artwork();
    passwordToggles(document);
    socials();
    gate("[data-signup-form]");
    redirectIfSignedIn();

    var form = KT.qs("[data-signup-form]");

    /* Password strength meter (presentation only). */
    var pw = KT.qs("#suPassword");
    var meter = KT.qs("[data-pw-meter]");
    if (pw && meter) {
      pw.addEventListener("input", function () {
        var v = pw.value;
        var score = 0;
        if (v.length >= 8) score++;
        if (/[A-Z]/.test(v)) score++;
        if (/[0-9]/.test(v)) score++;
        if (/[^A-Za-z0-9]/.test(v)) score++;
        var labels = ["Too short", "Weak", "Getting there", "Good", "Strong"];
        var colors = ["var(--ink-4)", "var(--chili)", "var(--amber)", "var(--mint)", "var(--mint)"];
        meter.style.setProperty("--pw", (score / 4) * 100 + "%");
        meter.style.setProperty("--pwc", colors[score]);
        KT.qs("[data-pw-label]").textContent = v ? labels[score] : "";
      });
    }

    form.addEventListener("submit", async function (e) {
      e.preventDefault();
      if (!KT.services) return;

      var fields = KT.qsa("input", form);
      var firstName = fields[0].value.trim();
      var lastName = fields[1].value.trim();
      var email = fields[2].value.trim();
      var phone = fields[3].value.trim();
      var password = pw.value;
      var agreed = KT.qsa(".checkline input")[0].checked;

      if (!firstName || !email || !password) {
        KT.toast("Fill in your name, email and password.", "info");
        return;
      }
      if (!KT.rules.isValidPhone(phone)) {
        KT.toast("Enter a valid Nigerian phone number — the rider needs it.", "info");
        return;
      }
      if (password.length < 6) {
        KT.toast("Use at least 6 characters for your password.", "info");
        return;
      }
      if (!agreed) {
        KT.toast("Please accept the terms to create an account.", "info");
        return;
      }

      busy(form, true, "Creating your account…");
      try {
        await KT.auth.signUp({ firstName: firstName, lastName: lastName, email: email, phone: phone, password: password });
        KT.toast("Account created — check your email to verify it.", "success", { duration: 5200 });
        window.location.href = KT.auth.nextUrl();
      } catch (error) {
        busy(form, false);
        fail(error);
      }
    });
  };
})(window.KT || (window.KT = {}));
